export enum Roles {
  Admin = 'admin',
  SuperAdmin = 'superadmin',
  Employee = 'employee',
}
